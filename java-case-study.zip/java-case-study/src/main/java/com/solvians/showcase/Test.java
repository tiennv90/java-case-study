package com.solvians.showcase;

import java.math.BigDecimal;

public class Test {
    public static void main(String[] args) {
        CertificateUpdate update = new CertificateUpdate(
                System.currentTimeMillis(),
                "DE123456789",
                new BigDecimal("150.25"),
                2000,
                new BigDecimal("151.75"),
                3500
        );
        System.out.println(update.toRecord());
    }
}
