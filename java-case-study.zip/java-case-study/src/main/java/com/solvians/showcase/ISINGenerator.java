package com.solvians.showcase;

import java.util.ArrayList;
import java.util.List;

public class ISINGenerator {

    private static String refineStep1(String convertibleString) {
        String s = convertibleString.substring(0,2);
        Character ch0 = s.charAt(0);
        Character ch1 = s.charAt(1);
        return (s.charAt(0) - 'A' + 10) + "" + (s.charAt(1) - 'A' + 10) + convertibleString.substring(2);
    }

    private static List<Integer> refineStep2(String refinedStep1) {
        StringBuilder builder = new StringBuilder(refinedStep1);
        String reversed = builder.reverse().toString();
        List<Integer> result = new ArrayList<>();
        for (int i = 0; i < reversed.length(); i++) {
            int novelty = (int) reversed.charAt(i);
            if (i % 2==0) {
                novelty = novelty * 2;
            }
            String s = Integer.toString(novelty);
            for (char c : s.toCharArray()) {
                result.add((int) c);
            }
        }
        return result;
    }

    private static int refineStep3(List<Integer> refinedStep2) {
        return refinedStep2.stream().mapToInt(Integer::intValue).sum();
    }

    private static int refineStep4(int refinedStep3) {
        int result = refinedStep3;
        while (result % 10 != 0) {
            result+=1;
        }
        return result - refinedStep3;
    }

    public static String generateISIN(String convertibleString) {
        String step1 = refineStep1(convertibleString);
        List<Integer> step2 = refineStep2(step1);
        int step3 = refineStep3(step2);
        return convertibleString + refineStep4(step3);
    }

}
