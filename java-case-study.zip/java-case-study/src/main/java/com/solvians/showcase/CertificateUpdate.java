package com.solvians.showcase;

import java.math.BigDecimal;

public class CertificateUpdate {

    // TODO: implement me.
    private Long timestamp;
    private String ISIN;
    private BigDecimal bidPrice;
    private Integer bidSize;
    private BigDecimal askPrice;
    private Integer askSize;

    public CertificateUpdate() {
        this.timestamp = System.currentTimeMillis();
    }

    public CertificateUpdate(Long timestamp, String ISIN, BigDecimal bidPrice, Integer bidSize, BigDecimal askPrice, Integer askSize) {
        this.timestamp = timestamp;
        this.ISIN = ISIN;
        this.bidPrice = bidPrice;
        this.bidSize = bidSize;
        this.askPrice = askPrice;
        this.askSize = askSize;
    }

    public String toRecord() {
        validate();
        StringBuilder builder = new StringBuilder();
        builder.append(timestamp).append(",").append(ISINGenerator.generateISIN(ISIN)).append(",")
                .append(bidPrice.setScale(2)).append(",").append(bidSize).append(",")
                .append(askPrice.setScale(2)).append(",").append(askSize);
        return builder.toString();
    }

    private void validate() {
        if (!isValidAskPrice()) {
            throw new RuntimeException("Ask Price is not valid");
        }
        if (!isValidBidSize()) {
            throw new RuntimeException("Bid Size is not valid");
        }
        if (!isValidISIN()) {
            throw new RuntimeException("ISIN is not valid");
        }
        if (!isValidTimestamp()) {
            throw new RuntimeException("Timestamp is not valid");
        }
        if (!isValidAskSize()) {
            throw new RuntimeException(("Ask size is not valid"));
        }
    }

    private boolean isValidTimestamp() {
        return timestamp >= 0 && timestamp <= System.currentTimeMillis();
    }

    private boolean isValidISIN() {
        return ISIN.matches("^[A-Z]{2}[A-Z0-9]{8}[0-9]$");
    }

    private boolean isValidNumber(BigDecimal price, int scale, double from, double to) {
        return price.scale() <= scale &&
                price.compareTo(BigDecimal.valueOf(from)) >= 0 &&
                price.compareTo(BigDecimal.valueOf(to)) <= 0;
    }

    private boolean isValidBidPrice() {
        return isValidNumber(bidPrice, 2, 100.00, 200.00);
    }

    private boolean isValidBidSize() {
        return bidSize >= 1000 && bidSize  <= 5000;
    }

    private boolean isValidAskPrice() {
        return isValidNumber(bidPrice, 2, 100.00, 200.00);
    }

    private boolean isValidAskSize() {
        return askSize >= 1000 && askSize  <= 10000;
    }


}
